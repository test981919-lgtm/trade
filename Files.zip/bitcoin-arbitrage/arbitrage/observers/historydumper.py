from arbitrage.observers.observer import Observer
import json
import time
import os


class HistoryDumper(Observer):
    out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "history"))
    opportunity_file = os.path.join(out_dir, "arbitrage-opportunities.json")
    latest_opportunity_file = os.path.join(out_dir, "latest-arbitrage-opportunity.json")

    def __init__(self):
        os.makedirs(self.out_dir, exist_ok=True)

    def begin_opportunity_finder(self, depths):
        filename = os.path.join(self.out_dir, "order-book-" + str(int(time.time())) + ".json")
        with open(filename, "w") as fp:
            json.dump(depths, fp)

    def end_opportunity_finder(self):
        pass

    def opportunity(
        self,
        profit,
        volume,
        buyprice,
        kask,
        sellprice,
        kbid,
        perc,
        weighted_buyprice,
        weighted_sellprice,
        gross_spread_pct=None,
        net_profit_pct=None,
    ):
        record = {
            "timestamp": time.time(),
            "profit": profit,
            "volume": volume,
            "buy_market": kask,
            "sell_market": kbid,
            "buy_price": buyprice,
            "sell_price": sellprice,
            "weighted_buy_price": weighted_buyprice,
            "weighted_sell_price": weighted_sellprice,
            "gross_spread_pct": perc if gross_spread_pct is None else gross_spread_pct,
            "net_profit_pct": perc if net_profit_pct is None else net_profit_pct,
        }
        try:
            with open(self.opportunity_file, "r") as fp:
                opportunities = json.load(fp)
        except (FileNotFoundError, json.JSONDecodeError):
            opportunities = []
        opportunities.append(record)
        with open(self.opportunity_file, "w") as fp:
            json.dump(opportunities, fp, indent=4)
            fp.write("\n")
        with open(self.latest_opportunity_file, "w") as fp:
            json.dump(record, fp, indent=4)
            fp.write("\n")
