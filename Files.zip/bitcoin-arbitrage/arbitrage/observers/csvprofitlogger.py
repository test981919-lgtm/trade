import csv
import datetime
import os

from .observer import Observer


class CSVProfitLogger(Observer):
    def __init__(self):
        self.history_dir = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "history")
        )
        self.file_path = os.path.join(self.history_dir, "detected_profits.csv")
        os.makedirs(self.history_dir, exist_ok=True)
        if not os.path.exists(self.file_path):
            with open(self.file_path, "w", newline="") as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow(
                    [
                        "Timestamp",
                        "Profit_USD",
                        "Volume_BTC",
                        "Buy_Exchange",
                        "Sell_Exchange",
                        "Profit_Pct",
                    ]
                )

    def opportunity(
        self,
        profit,
        volume,
        buyprice,
        kask,
        sellprice,
        kbid,
        perc,
        weighted_buyprice,
        weighted_sellprice,
    ):
        with open(self.file_path, "a", newline="") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(
                [
                    datetime.datetime.now().isoformat(timespec="seconds"),
                    profit,
                    volume,
                    kask,
                    kbid,
                    perc,
                ]
            )
